#########################################
#### Parse Running Wheel GUI version ####
#########################################

By Prech Uapinyoying
prw-gui - Version 0.1
https://github.com/puapinyoying

############
# Tutorial #
############

This program parses mouse running wheel data that has been output into an ASCII 
(.asc) file directly obtained from the Vitalview Software. The input file should
have two headers. The first will be the the over all file header that says 
'Experiment Logfile:' followed by the date. Second, the data header below in 
comma delimited format (csv).

The program will output a csv file for each of the following:

        1) Mice data - unmanipulated summary statistics from ASCII file

        2) Raw data - unmanipulated data from ASCII file

        3) Distance calculated - converted turns data into meters

        4) Time Filtered - option to set start and end date. If unchanged, all
           data will be used. This sheet also includes a few summary statistics
           calculated at the bottom rows.

        5) Sum Hourly - minute data is summed into hours per row

        6) Cumulative - data from each hour is compounded onto the previous

        7) Running Streaks - how many consecutive minutes each animal runs per
           session. This includes all running sessions for that particular
           animal.

Instructions: 

        1) To start click "Open File" and select a VitalView (.asc) data file.

        2) Once loaded, if you would like to filter the data by start and end
           date/time use the drop-down boxes and time edit boxes (time format in
           hh:mm:ss)

        3) The program will automatically output csv files of all the
           calculations listed above. Option to export the csv files into a
           single Excel workbook.

        4) Click "Parse Data" to start."""